#Extract basic blocks from a batch of binaries
#
#requires: Python 2.7.12 or other compatible version
#		   IDA Pro 6.2 or other compatible version
#		   getBBs.idc script  placed/symlinked in ida-6.2/idc
#		   Adjustment of input and output paths as needed
#
#input: Set of binaries in $HOME/Desktop/Data/binary directory
#output: One file per function, one node per basic block of that function into directory $HOME/Desktop/Data/raw_BB
#
#Note: MANY files will be output, choose your output directory wisely(ie. not desktop)
#	   Make sure you keep the input folder clean of anything you dont want operated on	
#

import os
import sys
from os.path import expanduser

def is_cleanup(name):
	return name.endswith('.i64') or name.endswith('.idb') or name.endswith('.id0') or name.endswith('.id1')or name.endswith('.nam') or name.endswith('.til')

def main():
	HOME=expanduser("~")
	#input_path = HOME+"/home/iftakhar/inp_op_for_BIN_to_GDL_py/x86_binary"
	#output_path = HOME+"/home/iftakhar/inp_op_for_BIN_to_GDL_py/x86_raw_BB"
	
	input_path = "/home/iftakhar/inp_op_for_BIN_to_GDL_py/x86_binary"
	output_path = "/home/iftakhar/inp_op_for_BIN_to_GDL_py/x86_raw_BB"
	if not os.path.exists(output_path):
		os.makedirs(output_path)
	input_names = os.listdir(input_path)

	#run script against all files
	for name in input_names:
		target_file = input_path+"/"+name		
		os.system("ida64 -c -A -SgetBBs.idc " + target_file)
		#os.system("ida64 -c -A -SgetBBs.idc " + target_file)

	# housekeeping
	# Delete ida database files and move the .gdl to raw_BB directory
	output_names = os.listdir(input_path)
	for name in output_names:
		if is_cleanup(name):
			target_file = input_path+"/"+name
			os.remove(target_file)
		elif name.endswith('.gdl'):
			move_from = input_path+"/"+name
			move_to = output_path+"/"+name
			os.rename(move_from, move_to)

if __name__ == "__main__":
	main()



	
